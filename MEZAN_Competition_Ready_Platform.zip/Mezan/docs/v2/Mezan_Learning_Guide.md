# Mezan | ميزان v2 — Learning guide: every method, how it works and how Mezan implements it

Generated from `carbon_iq/learning.py` (the same content as the app's Learning Center). Status is judged from the code. All synthetic-plant numbers are modelled on hypothetical data; MRC energy and emissions are Ma'aden's reported 2025 values (Sustainability Data Book 2025, PDF page 5) and every MRC investment figure is hypothetical.

## Method status

| # | Method | Status | What exactly |
|---|---|---|---|
| 1 | Scope 1 and Scope 2 emissions accounting | Fully implemented | Scope 1 and Scope 2 (location-based) fully; Scope 3 only for purchased steel and inbound freight. |
| 2 | Emission factors and unit conversions | Fully implemented | All factors and conversions are in one register with source, date and status. |
| 3 | Uncertainty propagation (error propagation) | Fully implemented | First-order rule per GHG Protocol / IPCC Approach 1; Monte Carlo (Approach 2) as a cross-check. |
| 4 | Reconciling recalculated and reported emissions | Fully implemented | Implemented for MRC (v2.1): Scope 1 recalculated from reported fuel use with IPCC factors and the difference explained; the Scope 2 factor implied by the report compared with the national average. |
| 5 | Data quality checks and missing-data estimation | Fully implemented | Fully implemented and tested on synthetic data only; not applicable to MRC (no monthly data published). |
| 6 | Monte Carlo simulation | Fully implemented | Synthetic plant: 20,000 scenarios + 200,000 for validation. MRC: same distributions, reporting basis. |
| 7 | Probability of meeting emissions targets (chance constraints) | Fully implemented | Carbon and budget chance constraints, sample-average approximation, tightened for sampling error. |
| 8 | Budget feasibility and minimum budget | Fully implemented | When no plan meets the rules, nothing is forced and the budget is never raised automatically; the model reports why, and the smallest budget that would make the rule feasible under its assumptions. |
| 9 | Expected Value of Perfect Information (EVPI) | Fully implemented | Implemented for the synthetic plant; A6 showed it is a lower bound when the confidence rules bind. Not run for MRC. |
| 10 | Value of Information (EVPPI and EVSI) | Fully implemented | EVPPI for 8 candidate measurements, EVSI for a motor audit, pre-posterior VoI for data gaps (A4). Not run for MRC. |
| 11 | Net Present Value (NPV) and simple payback | Fully implemented | NPV with optional output degradation (solar); payback computed and now shown on the Projects step. |
| 12 | Internal Rate of Return (IRR) | Fully implemented | Calculated per project (solar with degradation); shown on the Projects step from v2. |
| 13 | Return on Investment (ROI) | Not implemented | Not implemented as a named metric. The same question is answered by NPV, IRR, payback and NPV per riyal (profitability index, used as a ranking baseline). |
| 14 | Marginal Abatement Cost (MAC) | Fully implemented | SAR per tCO2e for every project; used in the 'cheapest tonne first' ranking baseline. |
| 15 | Single-criterion project ranking (comparison baselines) | Fully implemented | Three one-criterion rankings (NPV, NPV per riyal, cheapest tonne first) are computed and compared with the optimised portfolio. This is sorting on one number at a time, not multi-criteria decision analysis. |
| 16 | Multi-criteria decision analysis (MCDA, weighted scoring) | Not implemented | Not implemented. Mezan assigns no weights and computes no combined score. Its decision rules maximise expected NPV subject to carbon and budget confidence constraints - a constrained single-objective method, which is not MCDA. The single-criterion rankings above are not MCDA either. |
| 17 | Portfolio optimisation under a budget | Fully implemented | Binary integer program (HiGHS) cross-checked by enumerating all 64 portfolios; MRC uses the same functions on 16. |
| 18 | Sensitivity analysis | Fully implemented | Tornado, first-order variance indices, switch points, discount-rate robustness, price scenarios; Sobol indices in the A6 validation script. |
| 19 | Investment timing and flexibility (real options) | Partially implemented | Implemented for one project (D, heat recovery) and one uncertain price (gas): decision tree, GBM trigger, least-squares Monte Carlo. Not applied to MRC. |
| 20 | Decision-stability checks | Fully implemented | Monte Carlo margins in standard errors, perturbation of estimated data, switch points, knife-edge seeds, capital-cost risk and regret (synthetic plant); budget-margin check for MRC (v2.1). |
| 21 | Risk register | Not implemented | Not implemented as a feature. Open risks are tracked in ISSUE_LOG.md (a document) and listed under each recommendation's limitations; no likelihood, impact or owner is calculated or stored by the app. The only quantified risk is the capital-cost overrun probability (decisions.capex_risk). |

## How the methods connect

![How the methods connect](methods_flow.png)

Data are checked and completed, converted to emissions, valued as projects, combined into the best portfolio, then tested in simulated futures against the target and the budget. Value of information can send you back to collect better data; sensitivity, stability and timing check how robust and urgent the recommendation is. (Teaching order; in the code, optimisation, simulation and the confidence rules run together on the same scenarios.)

## 1. Scope 1 and Scope 2 emissions accounting

**Status: Fully implemented.**

**1 · What is it?** Turns energy and fuel records into tonnes of CO2-equivalent (tCO2e). Scope 1 is fuel burned on site, Scope 2 is purchased electricity, Scope 3 is the supply chain.

**2 · Where did it come from?** The GHG Protocol Corporate Standard by the World Resources Institute (WRI) and the World Business Council for Sustainable Development (WBCSD), 2001, revised 2004, defined the three scopes. Default emission factors come from the IPCC 2006 Guidelines.
- WRI & WBCSD (2004). The Greenhouse Gas Protocol: A Corporate Accounting and Reporting Standard, revised edition. [https://ghgprotocol.org/corporate-standard](https://ghgprotocol.org/corporate-standard)
- IPCC (2006). 2006 IPCC Guidelines for National Greenhouse Gas Inventories, Vol. 2 Energy, Ch. 2 Stationary Combustion. [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf)

**3 · Why does Mezan need it?** Everything else - the target, project savings, probabilities - is counted in tonnes. A wrong baseline makes every later answer wrong.

**4 · How does it work?**
1. Collect yearly activity data (MWh of electricity, GJ of gas, litres or GJ of diesel).
2. Multiply each by its emission factor (tCO2e per unit).
3. Add the results by scope; the target is a share of Scope 1+2.

**5 · Simple example** Synthetic plant: 12,000 MWh × 0.573 tCO2e/MWh = 6,876 t (Scope 2). MRC: 1,104,220 GJ of gas × 0.05615 tCO2e/GJ = 62,007 t, most of its reported Scope 1 (63,961 t).

**6 · How did we implement it?** Scope 1 and Scope 2 (location-based) fully; Scope 3 only for purchased steel and inbound freight.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/engine.py` | `baseline()` | parameter set p (activities and factors from assumptions.P) | one row per source: activity, factor, tCO2e, scope |
| `carbon_iq/engine.py` | `scope_totals()` | rows from baseline() | Scope 1, 2, 3, 1+2 and total |
| `carbon_iq/engine.py` | `target_t()` | p (target_share) | target in tCO2e/yr |
| `carbon_iq/mrc.py` | `scope1_recalc()` | MRC reported fuel GJ | recalculated Scope 1 vs the reported value |

**7 · How should I explain it to judges?**

> We start by measuring. Each energy record is multiplied by an official emission factor - for example 0.573 tonnes per megawatt-hour for the Saudi grid - and grouped into the GHG Protocol scopes. For Ma'aden Rolling, recalculating Scope 1 from its reported fuel use with IPCC factors lands within 0.3% of the figure Ma'aden reports.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/engine.py :: baseline()
def baseline(p=None):
    p = p or base_values()
    rows = [
        ("S1-GAS", "Scope 1", "Natural gas, process heat", p["gas_gj"], "GJ", p["ef_gas"]),
        ("S1-DSL-FL", "Scope 1", "Diesel, forklifts", p["diesel_forklift_l"], "L", p["ef_diesel"]),
        ("S1-DSL-GEN", "Scope 1", "Diesel, backup generators", p["diesel_genset_l"], "L", p["ef_diesel"]),
        ("S2-ELEC", "Scope 2", "Grid electricity (location-based)", p["elec_mwh"], "MWh", p["ef_grid"]),
        ("S3-C1-STEEL", "Scope 3 Cat 1", "Purchased steel", p["steel_t"], "t", p["ef_steel_incumbent"]),
        ("S3-C4-FRT", "Scope 3 Cat 4", "Inbound road freight", p["freight_tkm"], "t-km", p["ef_freight"]),
    ]
    out = [{"source_id": a, "scope": b, "source": c, "activity": d, "unit": e, "ef_t_per_unit": f, "emissions_t": d * f}
           for a, b, c, d, e, f in rows]
    return out
```

*Advanced:* Scope 2 is location-based (grid average). Market-based Scope 2 (contract-specific factors) is not implemented. GWPs are IPCC AR5 (CH4 28, N2O 265), as in Saudi Arabia's national inventory.

## 2. Emission factors and unit conversions

**Status: Fully implemented.**

**1 · What is it?** An emission factor says how much CO2e one unit of activity produces. Unit conversions make sure the activity and the factor use the same unit (GJ vs MWh, USD/MMBtu vs SAR/GJ).

**2 · Where did it come from?** Factor methodology: IPCC 2006 Guidelines. Saudi grid factor derived from Saudi Arabia's First Biennial Transparency Report (UNFCCC, 2025) and GASTAT 2021 generation. 1 MWh = 3.6 GJ is a definition.
- IPCC (2006). 2006 IPCC Guidelines for National Greenhouse Gas Inventories, Vol. 2 Energy, Ch. 2 Stationary Combustion. [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf)

**3 · Why does Mezan need it?** Most errors in carbon tools are unit errors. A factor in tCO2e per MWh applied to GJ gives an answer 3.6 times too big.

**4 · How does it work?**
1. Store every factor once, with unit, source and uncertainty (assumptions.P).
2. Convert the activity to the factor's unit before multiplying.
3. For gas prices, convert USD per MMBtu to SAR per GJ (× 3.75 SAR/USD ÷ 1.055 GJ/MMBtu).

**5 · Simple example** MRC electricity 1,040,392 GJ ÷ 3.6 = 288,998 MWh. Gas price USD 2.15/MMBtu × 3.75 ÷ 1.055 = SAR 7.64/GJ.

**6 · How did we implement it?** All factors and conversions are in one register with source, date and status.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/mrc.py` | `fuel_factor_t_per_gj()` | fuel name | IPCC CO2e factor in tCO2e/GJ |
| `carbon_iq/mrc.py` | `gj_to_mwh()` | GJ | MWh |
| `carbon_iq/assumptions.py` | `gas_price_sar_per_gj()` | USD/MMBtu | SAR/GJ |
| `carbon_iq/assumptions.py` | `add()` | key, value, unit, status, source, distribution | one entry in the register P |

**7 · How should I explain it to judges?**

> Every emission factor sits in one register with its unit, source, year and uncertainty. Before multiplying, Mezan converts the units - Ma'aden reports electricity in gigajoules, so we divide by 3.6 to get megawatt-hours. Getting the unit wrong is the most common carbon-accounting error, and the register makes every conversion visible.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/mrc.py :: fuel_factor_t_per_gj()
def fuel_factor_t_per_gj(key):
    """IPCC default CO2e factor in tCO2e per GJ: (CO2 + CH4 x 28 + N2O x 265) kg/TJ / 1e6."""
    _, co2, _, _, ch4, n2o = FUEL_FACTORS[key]
    return (co2 + ch4 * GWP_CH4 + n2o * GWP_N2O) / 1e6
```

*Advanced:* IPCC factors are per GJ of net calorific value. The Ma'aden data book does not say whether its GJ are net or gross; the close Scope 1 match suggests net, but that is an inference, not a fact.

## 3. Uncertainty propagation (error propagation)

**Status: Fully implemented.**

**1 · What is it?** Works out how the uncertainty of each meter and factor adds up to the uncertainty of the total, as ± percent at 95% confidence.

**2 · Where did it come from?** Combination rules from the theory of errors (Gauss, Laplace, early 1800s), standardised in the GUM (JCGM 100:2008) and adopted as 'Approach 1' in the IPCC 2006 Guidelines.
- JCGM 100:2008. Evaluation of measurement data - Guide to the Expression of Uncertainty in Measurement (GUM). BIPM. [https://www.bipm.org/en/doi/10.59161/JCGM100-2008E](https://www.bipm.org/en/doi/10.59161/JCGM100-2008E)
- IPCC (2006). 2006 Guidelines, Vol. 1, Ch. 3 Uncertainties (Approach 1: error propagation; Approach 2: Monte Carlo). [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf)

**3 · Why does Mezan need it?** Without a range, 9,054 t looks exact. Management needs to know how much safety margin a target needs.

**4 · How does it work?**
1. Give every input a ± percent (95%).
2. For activity × factor: U = √(U_activity² + U_factor²).
3. For a sum of sources, combine the ± tonnes the same way; big uncertain sources dominate.

**5 · Simple example** Electricity ±2%, grid factor ±9.8% → √(4 + 96) ≈ ±10%. MRC Scope 1 recalculation: ±4.0% (assuming ±2% metering).

**6 · How did we implement it?** First-order rule per GHG Protocol / IPCC Approach 1; Monte Carlo (Approach 2) as a cross-check.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/engine.py` | `uncertainty_table()` | baseline rows | ± % per source and per scope |
| `carbon_iq/engine.py` | `u_mult()` | ± percents of a product | combined ± percent |
| `carbon_iq/engine.py` | `u_add()` | (tonnes, ± percent) pairs | ± percent of the sum |

**7 · How should I explain it to judges?**

> Every number has a margin of error. Our electricity meter might be 2% off, but the national grid factor is uncertain by almost 10%, so the factor - not the meter - drives the uncertainty. We report 9,054 tonnes plus or minus 7.7%, instead of pretending the footprint is exact.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/engine.py :: uncertainty_table()
def uncertainty_table(rows=None):
    """First-order (Gaussian) propagation per GHG Protocol uncertainty guidance:
    source: U = sqrt(U_A^2 + U_EF^2); total: U = sqrt(sum (E_i U_i)^2) / sum E_i."""
    rows = rows or baseline()
    out = []
    for r in rows:
        ka, ke = ACTIVITY_KEY[r["source_id"]]
        ua = u95(ka)   # v1.1: every activity uncertainty comes from the assumption register (same inputs as the Monte Carlo)
        ue = u95(ke)
        uc = u_mult(ua, ue)
        label = next(lab for lim, lab in DQ_LABEL if uc <= lim)
        out.append({**r, "u_activity_pct": ua, "u_ef_pct": ue, "u_combined_pct": uc, "quality": label,
                    "first_order_valid": ua < 60 and ue < 60})
    def agg(sel):
        pairs = [(r["emissions_t"], r["u_combined_pct"]) for r in out if sel(r)]
        return sum(e for e, _ in pairs), u_add(pairs)
    tot = {"Scope 1": agg(lambda r: r["scope"] == "Scope 1"), "Scope 2": agg(lambda r: r["scope"] == "Scope 2"),
           "Scope 3": agg(lambda r: r["scope"].startswith("Scope 3")),
           "Scope 1+2": agg(lambda r: not r["scope"].startswith("Scope 3")), "Total": agg(lambda r: True)}
    return out, tot
```

*Advanced:* Valid for independent errors below roughly 30%; the code flags sources where it is not (freight ±36%).

## 4. Reconciling recalculated and reported emissions

**Status: Fully implemented.**

**1 · What is it?** Recalculates a company's reported emissions from its own reported activity data and explains any difference.

**2 · Where did it come from?** GHG Protocol quality-management guidance (Corporate Standard, ch. 7) and IPCC default factors and uncertainty ranges.
- WRI & WBCSD (2004). The Greenhouse Gas Protocol: A Corporate Accounting and Reporting Standard, revised edition. [https://ghgprotocol.org/corporate-standard](https://ghgprotocol.org/corporate-standard)
- IPCC (2006). 2006 IPCC Guidelines for National Greenhouse Gas Inventories, Vol. 2 Energy, Ch. 2 Stationary Combustion. [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf)
- IPCC (2006). 2006 Guidelines, Vol. 1, Ch. 3 Uncertainties (Approach 1: error propagation; Approach 2: Monte Carlo). [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf)

**3 · Why does Mezan need it?** Before building a decision on a company's baseline, check that it is consistent - and know which parts cannot be checked.

**4 · How does it work?**
1. Multiply each reported fuel (GJ) by its IPCC factor and add up.
2. Compare with the reported Scope 1; express the difference as a share of the recalculation's uncertainty.
3. Back-calculate the Scope 2 factor (Scope 2 ÷ MWh) and compare it with independent factors - remembering that a back-calculated factor is derived, not verified.

**5 · Simple example** MRC: 64,105 t recalculated vs 63,961 t reported (+144 t, +0.22%); the 95% uncertainty is ±2,535 t, so the two agree. A gas factor 0.23% below the IPCC default would close the gap exactly.

**6 · How did we implement it?** Implemented for MRC (v2.1): Scope 1 recalculated from reported fuel use with IPCC factors and the difference explained; the Scope 2 factor implied by the report compared with the national average.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/mrc.py` | `scope1_reconciliation()` | reported fuel GJ and Scope 1 | gap, its share of the uncertainty, tests of possible causes |
| `carbon_iq/mrc.py` | `scope1_recalc()` | reported fuel GJ | recalculated Scope 1 with ± uncertainty |
| `carbon_iq/mrc.py` | `grid_factor_comparison()` | reported Scope 2 and electricity | implied vs national vs verified factor |

**7 · How should I explain it to judges?**

> We tested Ma'aden Rolling's reported Scope 1 by recalculating it from its fuel use. We are within 144 tonnes - 0.2% - well inside the uncertainty. For Scope 2 the report implies a grid factor of 0.335, far below the national 0.573; that is a derived number, not a verified one, so it is our first question to the company.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/mrc.py :: scope1_reconciliation()
def scope1_reconciliation():
    """v2.1 - explains the gap between the recalculated and the reported Scope 1 (all values in tCO2e)."""
    s = scope1_recalc()
    co2 = sum(v(k) * FUEL_FACTORS[k][1] / 1e6 for k in FUEL_FACTORS)
    gwp = lambda ch4, n2o: sum(v(k) * (FUEL_FACTORS[k][1] + FUEL_FACTORS[k][4] * ch4 + FUEL_FACTORS[k][5] * n2o) / 1e6 for k in FUEL_FACTORS)
    co2_lo = sum(v(k) * FUEL_FACTORS[k][2] / 1e6 for k in FUEL_FACTORS)
    co2_hi = sum(v(k) * FUEL_FACTORS[k][3] / 1e6 for k in FUEL_FACTORS)
    gcv = sum(v(k) * fuel_factor_t_per_gj(k) * (0.90 if k == "natural_gas_gj" else 0.95) for k in FUEL_FACTORS)
    gas_close = s["diff_t"] / v("natural_gas_gj") * 1e6          # kg CO2 per TJ change that closes the gap
    return dict(reported=s["reported_t"], recalculated=s["total_t"], diff_t=s["diff_t"], diff_pct=s["diff_pct"],
                co2_only=co2, non_co2=s["total_t"] - co2, u95_t=s["total_t"] * s["u95_pct"] / 100, u95_pct=s["u95_pct"],
                diff_share_of_u95=abs(s["diff_t"]) / (s["total_t"] * s["u95_pct"] / 100),
                ar4=gwp(25, 298), ar6=gwp(29.8, 273), co2_range=(co2_lo, co2_hi), if_gross_cv=gcv,
                gas_factor_to_close=FUEL_FACTORS["natural_gas_gj"][1] - gas_close, gas_change_pct=-100 * gas_close / FUEL_FACTORS["natural_gas_gj"][1])
```

*Advanced:* AR4 or AR6 greenhouse-gas weights change the recalculation by under 4 t; gross instead of net heating values would lower it by about 10%, which would no longer match.

## 5. Data quality checks and missing-data estimation

**Status: Fully implemented.**

**1 · What is it?** Checks monthly records for gaps, duplicates, unit errors and outliers, then estimates missing months with a stated range - never treating missing data as zero.

**2 · Where did it come from?** Missing-data theory from Rubin (1976) and Little & Rubin; prediction intervals calibrated with split-conformal prediction (Vovk et al., 2005).
- Rubin, D. B. (1976). Inference and missing data. Biometrika 63(3), 581-592. [https://doi.org/10.1093/biomet/63.3.581](https://doi.org/10.1093/biomet/63.3.581)
- Little, R. J. A. & Rubin, D. B. (2019). Statistical Analysis with Missing Data, 3rd ed. Wiley. [https://doi.org/10.1002/9781119482260](https://doi.org/10.1002/9781119482260)
- Vovk, V., Gammerman, A. & Shafer, G. (2005). Algorithmic Learning in a Random World. Springer (conformal prediction). [https://doi.org/10.1007/b106715](https://doi.org/10.1007/b106715)

**3 · Why does Mezan need it?** Counting a missing month as zero hides emissions: in the synthetic demo it hides 25% of Scope 1+2 and changes the plan.

**4 · How does it work?**
1. Check every record (units, duplicates, invalid values, robust z-score outliers, suspicious zeros).
2. Estimate each gap with the method that back-tests best: seasonal history, production intensity or monthly mean.
3. Attach a 95% interval, refuse long gaps (> 3 months) or unstable data, and require reviewer approval.

**5 · Simple example** March missing; March last year 980 MWh; this year runs 3% higher → 980 × 1.03 ≈ 1,009 MWh ± a back-tested range.

**6 · How did we implement it?** Fully implemented and tested on synthetic data only; not applicable to MRC (no monthly data published).

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/dataquality/quality.py` | `assess()` | raw monthly records, year, site | cells with status and issues |
| `carbon_iq/dataquality/estimate.py` | `propose()` | cells (and previous year) | estimates, intervals, refusals, warnings |
| `carbon_iq/dataquality/estimate.py` | `Ledger()` | raw records | audit trail, reviewer decisions, annual totals |
| `carbon_iq/dataquality/integrate.py` | `run_decisions()` | annual activity with standard deviations | the decision rules' choices |

**7 · How should I explain it to judges?**

> Real data always have holes. If you count a missing bill as zero, our test plant's footprint drops by a quarter and the plan changes. Mezan estimates each gap from the plant's own history, shows how wrong it could be, and needs a person to approve it.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/dataquality/quality.py :: assess()
def assess(raw, year, site=None):
    """Return (cells, issues): one row per (site, period, stream) for the reporting year, and a list of issues.

    cells columns: site, period, stream, unit, raw_values, raw_units, record_ids, value (canonical, after exact
    unit conversion; NaN if unusable), status, issues"""
    validate_schema(raw)
    df = raw.copy()
    if "record_id" not in df.columns:
        df["record_id"] = [f"R{i+1:05d}" for i in range(len(df))]
    for c in ("source", "note"):
        if c not in df.columns:
            df[c] = ""
    df["note"] = df["note"].astype(object).where(df["note"].notna(), "").astype(str)
    sites = [site] if site else sorted(df["site"].dropna().unique())
    issues = []
    for s in sorted(set(df["stream"]) - set(STREAMS)):
        issues.append(dict(site="*", period="*", stream=s, code="UNKNOWN_STREAM", severity="error",
                           detail="stream not in schema; records ignored"))
    rows = []
    groups = {k: g for k, g in df.groupby(["site", "stream", "period"], sort=False)}
    empty = df.iloc[0:0]
    for st in sites:
        for stream, cfg in STREAMS.items():
            for per in periods_for(year):
                sub = groups.get((st, stream, per), empty)
                cell = dict(site=st, period=per, stream=stream, unit=cfg["unit"], raw_values=list(sub["value"]),
                            raw_units=list(sub["unit"]), record_ids=list(sub["record_id"]), notes=" | ".join(n for n in sub["note"] if n),
                            value=np.nan, status="missing", issues=[])
    # ... 38 more lines in carbon_iq/dataquality/quality.py
```

*Advanced:* Calibration factor 1.0898 and within-stream correlation 0.12 were fitted on synthetic facilities and must be re-fitted on real records.

## 6. Monte Carlo simulation

**Status: Fully implemented.**

**1 · What is it?** Runs the plan through thousands of randomly drawn futures (prices, savings, costs) to see the full range of outcomes.

**2 · Where did it come from?** Developed at Los Alamos by Ulam, von Neumann and Metropolis (1946-49); first paper Metropolis & Ulam (1949). The IPCC calls it 'Approach 2' for inventory uncertainty.
- Metropolis, N. & Ulam, S. (1949). The Monte Carlo method. Journal of the American Statistical Association 44(247), 335-341. [https://doi.org/10.1080/01621459.1949.10483310](https://doi.org/10.1080/01621459.1949.10483310)
- IPCC (2006). 2006 Guidelines, Vol. 1, Ch. 3 Uncertainties (Approach 1: error propagation; Approach 2: Monte Carlo). [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf)

**3 · Why does Mezan need it?** A single best guess hides risk. Management needs to know how often a plan could miss the target or the budget.

**4 · How does it work?**
1. Give each uncertain input a distribution (e.g. compressed-air savings uniform 10-30%).
2. Draw one value of every input and compute cost, tonnes and NPV - one future.
3. Repeat many times and count: averages, percentiles, probabilities.

**5 · Simple example** Recommended plan A+B+C: average NPV SAR 2.56M over 20,000 futures; it loses money in 0.11% of them (22 of 20,000).

**6 · How did we implement it?** Synthetic plant: 20,000 scenarios + 200,000 for validation. MRC: same distributions, reporting basis.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/uncertainty.py` | `sample()` | n, seed (distributions from assumptions.P) | n joint values of every input |
| `carbon_iq/uncertainty.py` | `Scenarios()` | sampled parameters | NPV, tonnes and cost of all 64 portfolios per scenario |
| `carbon_iq/decisions.py` | `validation_sample()` | n = 200,000, separate seed | independent check of the probabilities |
| `carbon_iq/mrc.py` | `monte_carlo()` | MRC parameter set | probabilities for the 16 MRC portfolios |

**7 · How should I explain it to judges?**

> The future is uncertain, so we don't trust a single forecast. Mezan plays out 20,000 possible futures with different tariffs, savings and costs, and records what happens to every plan. The recommended plan lost money in about one future in nine hundred - a measured probability, not a feeling.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/uncertainty.py :: sample()
def sample(n=20000, seed=20261024, fixed=None):
    """Draw n joint scenarios from the assumption register's distributions (independent inputs).

    Parameters on stream 1 use the v1.0 generator in register order, so their draws are unchanged from v1.0.
    Distributions added in v1.1 (stream 2) and v1.3 (stream 3) use independent generators, so their effect can be isolated
    and the earlier draws of every other input are unchanged."""
    rng = np.random.default_rng(seed)
    rng2 = np.random.default_rng([seed, 2])
    rng3 = np.random.default_rng([seed, 3])
    out = {}
    for k, p in P.items():
        if fixed and k in fixed:
            if p.dist is not None and p.stream == 1:
                _draw(rng, p, n)          # keep the stream-1 sequence aligned for the other parameters
            out[k] = np.full(n, float(fixed[k])); continue
        out[k] = _draw({2: rng2, 3: rng3}.get(p.stream, rng), p, n)
    return out
```

*Advanced:* Inputs are drawn independently (no correlation between prices). More runs make the answer precise, not correct.

## 7. Probability of meeting emissions targets (chance constraints)

**Status: Fully implemented.**

**1 · What is it?** A rule that accepts only plans meeting the carbon target - and staying within budget - in at least, say, 90% of simulated futures.

**2 · Where did it come from?** Chance-constrained programming by Charnes & Cooper (1959); scenario-based solution (sample average approximation) studied by Pagnoncelli, Ahmed & Shapiro (2009).
- Charnes, A. & Cooper, W. W. (1959). Chance-constrained programming. Management Science 6(1), 73-79. [https://doi.org/10.1287/mnsc.6.1.73](https://doi.org/10.1287/mnsc.6.1.73)
- Pagnoncelli, B. K., Ahmed, S. & Shapiro, A. (2009). Sample average approximation method for chance constrained programming. J. Optimization Theory and Applications 142, 399-416. [https://doi.org/10.1007/s10957-009-9523-6](https://doi.org/10.1007/s10957-009-9523-6)

**3 · Why does Mezan need it?** 'Meets the target on average' can mean failing half the time. This turns management's risk appetite into a test.

**4 · How does it work?**
1. Management sets confidence levels (90% carbon, 90% budget).
2. For every plan count the share of futures meeting the target and the budget.
3. Keep plans passing both; choose the highest expected NPV (rule D4).

**5 · Simple example** A+B meets the target in the single best guess but only in 93.5% of futures; A+B+C in more than 99.99% and within budget in 98.8% → chosen.

**6 · How did we implement it?** Carbon and budget chance constraints, sample-average approximation, tightened for sampling error.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/uncertainty.py` | `Scenarios.decide()` | budget, target, alpha, budget reliability | chosen portfolio and probabilities |
| `carbon_iq/uncertainty.py` | `alpha_saa()` | required level, number of scenarios | tightened level (0.9035 for 90%, n = 20,000) |
| `carbon_iq/decisions.py` | `choose()` | portfolio probabilities, budget, levels | index of the qualifying max-E[NPV] portfolio |

**7 · How should I explain it to judges?**

> Management told us: we want at least 90% confidence of hitting the carbon target and 90% confidence of staying on budget. Mezan applies exactly that rule to every plan. The recommended plan met the target in more than 99.99% of simulated futures and stayed on budget in 98.8% - modelled, not guaranteed.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/uncertainty.py :: Scenarios.decide()
    def decide(self, budget, target, alpha, mask=None, budget_reliability=None):
        """SAA chance-constrained choice on the scenarios in `mask`. Falls back to the highest target probability.

        Returns (k, E[NPV], P(target), feasible). With budget_reliability=b, portfolios must also stay within budget
        in at least a share b of the scenarios; if none qualifies, k is None."""
        m = np.ones(self.n, bool) if mask is None else mask
        cand = self.candidates(budget, budget_reliability, m)
        if not cand:
            return None, None, None, False
        en = {k: self.PNPV[k][m].mean() for k in cand}
        pt = {k: (self.PT12[k][m] >= target).mean() for k in cand}
        ok = [k for k in cand if pt[k] >= alpha - 1e-12]
        k = max(ok, key=lambda k: en[k]) if ok else max(cand, key=lambda k: (pt[k], en[k]))
        return k, en[k], pt[k], bool(ok)
```

*Advanced:* If no plan qualifies, none is forced; the model reports the minimum budget that would make the rule feasible.

## 8. Budget feasibility and minimum budget

**Status: Fully implemented.**

**1 · What is it?** Checks whether any plan can meet the target within the budget - and, if not, how much budget would be needed.

**2 · Where did it come from?** Chance-constrained programming (Charnes & Cooper, 1959) evaluated on simulated scenarios (Pagnoncelli et al., 2009).
- Charnes, A. & Cooper, W. W. (1959). Chance-constrained programming. Management Science 6(1), 73-79. [https://doi.org/10.1287/mnsc.6.1.73](https://doi.org/10.1287/mnsc.6.1.73)
- Pagnoncelli, B. K., Ahmed, S. & Shapiro, A. (2009). Sample average approximation method for chance constrained programming. J. Optimization Theory and Applications 142, 399-416. [https://doi.org/10.1007/s10957-009-9523-6](https://doi.org/10.1007/s10957-009-9523-6)

**3 · Why does Mezan need it?** A tool that quietly raises the budget until a plan works hides the real trade-off. Management must see it and decide.

**4 · How does it work?**
1. For each plan that meets the carbon rule, find the actual cost it stays under in 90% of futures (its 90th-percentile cost).
2. The plan's budget need is the larger of that cost and its quoted cost.
3. The smallest need over all plans is the minimum feasible budget; if no plan meets the carbon rule, the target is out of reach at any budget.

**5 · Simple example** Synthetic plant: at a solar cost of SAR 3,750/kWp no plan passes both 90% rules within SAR 5M; the minimum budget is SAR 5.44M. MRC scenario: A+B+C needs SAR 69.9M of the SAR 70M budget.

**6 · How did we implement it?** When no plan meets the rules, nothing is forced and the budget is never raised automatically; the model reports why, and the smallest budget that would make the rule feasible under its assumptions.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/decisions.py` | `_min_budget()` | scenarios, probabilities, required levels | smallest feasible budget |
| `carbon_iq/decisions.py` | `budget_analysis()` | scenarios, target, levels, budget | budget curve and needs per plan |
| `carbon_iq/mrc.py` | `budget_feasibility()` | MRC parameters and simulation | deterministic and probabilistic minimum budgets |

**7 · How should I explain it to judges?**

> If no plan fits, Mezan does not quietly raise the budget. It says why, and what the minimum budget would be under its assumptions - for example 5.44 million riyals if solar costs 50% more. Whether to spend it is management's decision.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/decisions.py :: _min_budget()
def _min_budget(sc, pr, a_eff, b_eff):
    """Smallest budget at which the joint rule D4 is feasible (carbon level met; b_eff quantile of actual capex)."""
    need = [max(float(np.quantile(sc.PCAP[k], b_eff, method="higher")), float(sc.capex[k]))
            for k in range(len(sc.ports)) if pr["p_target"][k] >= a_eff - 1e-12]
    return min(need) if need else None
```

*Advanced:* The minimum budget uses the same sampling-tightened level as the decision rule (0.9035 for 90% with 20,000 futures).

## 9. Expected Value of Perfect Information (EVPI)

**Status: Fully implemented.**

**1 · What is it?** The most you should ever pay for information before deciding: the gain if every uncertainty were known in advance.

**2 · Where did it come from?** Bayesian decision theory: Raiffa & Schlaifer (1961); named 'information value theory' by Howard (1966).
- Howard, R. A. (1966). Information value theory. IEEE Transactions on Systems Science and Cybernetics 2(1), 22-26. [https://doi.org/10.1109/TSSC.1966.300074](https://doi.org/10.1109/TSSC.1966.300074)
- Raiffa, H. & Schlaifer, R. (1961). Applied Statistical Decision Theory. Harvard Business School (book; no free link).

**3 · Why does Mezan need it?** It caps the budget for studies. If EVPI is small, more studies cannot improve the decision much.

**4 · How does it work?**
1. Value of deciding now = expected NPV of today's best plan.
2. For each scenario, imagine you knew it and picked the best plan for it.
3. EVPI = average of those best values − value of deciding now.

**5 · Simple example** Synthetic plant: EVPI ≈ SAR 55,670, small next to the plan's expected NPV of SAR 2.56M.

**6 · How did we implement it?** Implemented for the synthetic plant; A6 showed it is a lower bound when the confidence rules bind. Not run for MRC.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/voi.py` | `evpi()` | scenarios, budget, target, required probability | EVPI in SAR |

**7 · How should I explain it to judges?**

> Before spending millions, we ask what a perfect crystal ball would be worth - knowing every uncertain number in advance. For our test plant it is about 56,000 riyals, tiny next to a 2.5-million-riyal expected value. So no study, however good, can change much here: the decision is ready to be taken.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/voi.py :: evpi()
def evpi(sc, budget, target, alpha):
    _, e0 = prior(sc, budget, target, alpha)
    cand = [k for k in range(len(sc.ports)) if sc.capex[k] <= budget + 1e-6]
    V = np.where(sc.PT12[cand] >= target, sc.PNPV[cand], -np.inf)
    best = V.max(axis=0)
    # scenarios where no portfolio can meet the target: choose the largest-reduction portfolio's NPV
    fallback = sc.PNPV[cand][np.argmax(sc.PT12[cand], axis=0), np.arange(sc.n)]
    best = np.where(np.isfinite(best), best, fallback)
    return float(best.mean() - e0)
```

*Advanced:* Under the chance-constraint rule, the perfect-information benchmark can be defined two ways; A6 found the coded one is the lower bound (alternative SAR 74,267).

## 10. Value of Information (EVPPI and EVSI)

**Status: Fully implemented.**

**1 · What is it?** Prices one specific piece of information - perfect (EVPPI) or from a real, imperfect measurement (EVSI) - by asking whether it could change the decision.

**2 · Where did it come from?** Same Bayesian decision theory as EVPI (Raiffa & Schlaifer 1961; Howard 1966).
- Howard, R. A. (1966). Information value theory. IEEE Transactions on Systems Science and Cybernetics 2(1), 22-26. [https://doi.org/10.1109/TSSC.1966.300074](https://doi.org/10.1109/TSSC.1966.300074)
- Raiffa, H. & Schlaifer, R. (1961). Applied Statistical Decision Theory. Harvard Business School (book; no free link).

**3 · Why does Mezan need it?** Sub-meters, audits and supplier data cost money. Only information that can change the choice is worth buying.

**4 · How does it work?**
1. Group the scenarios by the value of one input (20 groups).
2. In each group find the best plan; average those values.
3. Subtract the value of deciding now; compare with the collection cost.

**5 · Simple example** Compressed-air sub-metering: EVPPI SAR 35,954 vs assumed cost SAR 40,000 → not quite worth it. Motor audit: EVSI 0.

**6 · How did we implement it?** EVPPI for 8 candidate measurements, EVSI for a motor audit, pre-posterior VoI for data gaps (A4). Not run for MRC.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/voi.py` | `evppi()` | scenarios, one input's values | value of resolving that input |
| `carbon_iq/voi.py` | `evsi_audit()` | scenarios, audit error | value of an imperfect audit |
| `carbon_iq/voi.py` | `ranking()` | scenarios | all candidate measurements, values and costs |
| `carbon_iq/dataquality/integrate.py` | `information_value()` | activity with gaps | value of collecting missing records |

**7 · How should I explain it to judges?**

> Not all missing information is worth buying. Of eight possible measurements, only one - sub-metering the compressed-air system - could change our decision, and it is worth about 36,000 riyals. If it costs less than that, measure first; if not, go ahead. Everything else would not change what we do.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/voi.py :: evppi()
def evppi(sc, x, budget, target, alpha, nb=20):
    _, e0 = prior(sc, budget, target, alpha)
    val, choices = _value(sc, budget, target, alpha, bins(x, nb))
    return float(val - e0), choices
```

*Advanced:* Binning estimators carry small noise; an irrelevant dummy variable is evaluated to show the noise floor.

## 11. Net Present Value (NPV) and simple payback

**Status: Fully implemented.**

**1 · What is it?** NPV is a project's total value in today's riyals: discounted future savings minus the investment. Payback is the number of years to recover the cost.

**2 · Where did it come from?** Discounting goes back to Irving Fisher (1907, 1930); NPV became standard capital budgeting in the 1950s and is prescribed for public appraisal in the UK Treasury Green Book.
- HM Treasury (2022). The Green Book: appraisal and evaluation in central government. [https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government](https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government)

**3 · Why does Mezan need it?** Savings arrive over 10-25 years; a riyal in year 20 is worth less than one today. NPV compares projects fairly.

**4 · How does it work?**
1. Estimate the cost and the yearly net saving.
2. Divide each year's saving by (1 + r)^t and add them up (r = 6% real).
3. Subtract the cost. Payback = cost ÷ yearly saving.

**5 · Simple example** Solar: SAR 2.5M cost, SAR 308,000 a year → payback 8.1 years; NPV over 25 years ≈ +SAR 1.25M.

**6 · How did we implement it?** NPV with optional output degradation (solar); payback computed and now shown on the Projects step.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/engine.py` | `npv()` | capex, annual cash flow, rate, years | NPV in SAR |
| `carbon_iq/engine.py` | `degraded_annuity_factor()` | rate, years, degradation | discount factor for declining output |
| `carbon_iq/engine.py` | `simple_payback()` | capex, annual cash flow | years |
| `carbon_iq/engine.py` | `projects()` | parameter set p | capex, cash flow, NPV, tonnes for projects A-F |

**7 · How should I explain it to judges?**

> For each project we ask what it is worth today after discounting future savings - that's NPV - and how quickly the money comes back - that's payback. Solar pays back in about eight years and is worth 1.25 million riyals today.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/engine.py :: npv()
def npv(capex, annual_cf, r, n):
    return -capex + annual_cf * annuity_factor(r, n)
```

*Advanced:* Payback ignores everything after the payback year and the time value of money, so Mezan never optimises it.

## 12. Internal Rate of Return (IRR)

**Status: Fully implemented.**

**1 · What is it?** The discount rate at which a project's NPV is exactly zero - its 'interest rate' on the money invested.

**2 · Where did it come from?** A standard capital-budgeting measure alongside NPV (UK Treasury Green Book discusses both).
- HM Treasury (2022). The Green Book: appraisal and evaluation in central government. [https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government](https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government)

**3 · Why does Mezan need it?** Managers often compare projects with a hurdle rate. IRR above the hurdle rate = NPV positive at that rate.

**4 · How does it work?**
1. Write NPV as a function of the rate r.
2. Search for the r where NPV = 0 (bisection).
3. Compare with the company's hurdle rate.

**5 · Simple example** Solar: IRR ≈ 11.0% > 6% discount rate → positive NPV. Heat recovery: IRR negative → loses money.

**6 · How did we implement it?** Calculated per project (solar with degradation); shown on the Projects step from v2.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/engine.py` | `irr()` | capex, annual cash flow, years | IRR (bisection), or None |
| `carbon_iq/engine.py` | `project_irr()` | project record, degradation | IRR with declining solar output |

**7 · How should I explain it to judges?**

> IRR is the yearly return a project earns on the money invested - like an interest rate. Solar earns about 11% a year, well above our 6% discount rate, so it creates value. Heat recovery has a negative IRR at today's gas price. We report IRR, but we optimise on NPV, which handles projects of different sizes correctly.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/engine.py :: irr()
def irr(capex, annual_cf, n, lo=-0.99, hi=1.0):
    """IRR of -capex followed by n equal flows (bisection). None if no sign change."""
    f = lambda r: -capex + annual_cf * float(annuity_factor(r, n))
    if f(lo) * f(hi) > 0:
        return None
    for _ in range(200):
        mid = (lo + hi) / 2
        if f(lo) * f(mid) <= 0:
            hi = mid
        else:
            lo = mid
    return (lo + hi) / 2
```

*Advanced:* IRR can mislead when comparing projects of different size; Mezan ranks and optimises on NPV.

## 13. Return on Investment (ROI)

**Status: Not implemented.**

**1 · What is it?** ROI usually means (total gain − cost) ÷ cost. It ignores when the money arrives.

**2 · Where did it come from?** A common business ratio with no single standard definition; discounted alternatives (NPV, IRR) are set out in the UK Treasury Green Book.
- HM Treasury (2022). The Green Book: appraisal and evaluation in central government. [https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government](https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government)

**3 · Why does Mezan need it?** Mezan deliberately uses discounted measures instead, because the projects last 10-25 years.

**4 · How does it work?**
1. Not computed. If needed: ROI = (sum of yearly net savings − cost) ÷ cost, undiscounted.
2. The nearest implemented measure is NPV ÷ capex (profitability index).
3. Report it only with its definition.

**5 · Simple example** Illustration only: solar 25 × SAR 308,000 − SAR 2.5M = SAR 5.2M gain → ROI 208% (undiscounted, ignores degradation).

**6 · How did we implement it?** Not implemented as a named metric. The same question is answered by NPV, IRR, payback and NPV per riyal (profitability index, used as a ranking baseline).

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/optimize.py` | `baselines()` | projects, budget, target | ranking by NPV per riyal (profitability index) |

**7 · How should I explain it to judges?**

> We deliberately do not report simple ROI. It adds up savings without asking when they arrive, so a 25-year solar plant looks the same as one that pays back immediately. NPV, IRR and payback answer the same question properly, and every one of them is shown for each project.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/optimize.py :: baselines()
def baselines(prj, inter, budget, target):
    from .engine import mac
    out = [
        greedy(prj, inter, budget, lambda i: -float(prj[i]["npv"]) / float(prj[i]["capex"]), "Rank by NPV per riyal (profitability index)"),
        greedy(prj, inter, budget, lambda i: -float(prj[i]["npv"]), "Rank by NPV"),
        greedy(prj, inter, budget, lambda i: float(mac(prj[i])) if i != "F" else 1e9, "Rank by abatement cost (MAC), cheapest first",
               require_positive_npv=False),
    ]
    for o in out:
        o["meets_target"] = o["scope12_t"] >= target - 1e-9
    return out
```

*Advanced:* Adding ROI would be a one-line display change; it is not added to avoid a metric without a fixed definition.

## 14. Marginal Abatement Cost (MAC)

**Status: Fully implemented.**

**1 · What is it?** The cost of avoiding one tonne of CO2e with a project. Negative means the project saves money while cutting emissions.

**2 · Where did it come from?** Used in energy policy since the 1990s and popularised by McKinsey cost curves (2007-09); pitfalls reviewed by Kesicki & Ekins (2012).
- Kesicki, F. & Ekins, P. (2012). Marginal abatement cost curves: a call for caution. Climate Policy 12(2), 219-236. [https://ideas.repec.org/a/taf/tcpoxx/v12y2012i2p219-236.html](https://ideas.repec.org/a/taf/tcpoxx/v12y2012i2p219-236.html)

**3 · Why does Mezan need it?** It connects money and carbon, and it is the most common way companies rank climate projects today.

**4 · How does it work?**
1. Take the project's NPV.
2. Divide −NPV by its discounted lifetime tonnes.
3. Sort: cheapest tonnes first.

**5 · Simple example** Solar −SAR 97/t (saves money); heat recovery +SAR 107/t (costs money per tonne).

**6 · How did we implement it?** SAR per tCO2e for every project; used in the 'cheapest tonne first' ranking baseline.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/engine.py` | `mac()` | project record from projects() | SAR per tCO2e |

**7 · How should I explain it to judges?**

> Marginal abatement cost tells you what each tonne of CO2 costs to avoid; negative means the project saves money. But funding the cheapest tonnes first, as many companies do, would pick a plan that loses money in our test case - which is why Mezan optimises the whole portfolio instead of sorting projects.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/engine.py :: mac()
def mac(d):
    """Marginal abatement cost, SAR per tCO2e: -NPV / discounted lifetime tonnes, i.e. -NPV / (AF_t x year-1 tonnes),
    where AF_t is the annuity factor (or the degraded factor for a declining output). Equals the equivalent annual cost
    divided by annual tonnes when tonnes are constant."""
    t = d["scope12_t"] + d["scope3_t"]
    return -d["npv"] / (d.get("af_t", d["af"]) * t) if np.all(np.abs(t) > 1e-9) else float("nan")
```

*Advanced:* A ratio ignores project size, budget and overlaps between projects.

## 15. Single-criterion project ranking (comparison baselines)

**Status: Fully implemented.**

**1 · What is it?** Sorts projects by one number - for example NPV or cost per tonne - and funds them from the top until the money runs out.

**2 · Where did it come from?** Capital rationing and the profitability index (Lorie & Savage, 1955); cost-per-tonne ranking from MAC curves (reviewed by Kesicki & Ekins, 2012).
- Lorie, J. H. & Savage, L. J. (1955). Three problems in rationing capital. Journal of Business 28(4), 229-239. [https://ideas.repec.org/r/ucp/jnlbus/v28y1955p229.html](https://ideas.repec.org/r/ucp/jnlbus/v28y1955p229.html)
- Kesicki, F. & Ekins, P. (2012). Marginal abatement cost curves: a call for caution. Climate Policy 12(2), 219-236. [https://ideas.repec.org/a/taf/tcpoxx/v12y2012i2p219-236.html](https://ideas.repec.org/a/taf/tcpoxx/v12y2012i2p219-236.html)

**3 · Why does Mezan need it?** It is how many companies choose today, so it is the fair baseline to show what optimisation adds.

**4 · How does it work?**
1. Compute one score per project (NPV, NPV ÷ capex, or MAC).
2. Sort the projects by that score.
3. Fund down the list while the budget allows; compare with the optimiser's portfolio.

**5 · Simple example** Cheapest tonne first funds A+B+C+D+F: SAR 4.70M, NPV −SAR 0.56M. Ranking by NPV funds A+B+C - here the same as the optimiser.

**6 · How did we implement it?** Three one-criterion rankings (NPV, NPV per riyal, cheapest tonne first) are computed and compared with the optimised portfolio. This is sorting on one number at a time, not multi-criteria decision analysis.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/optimize.py` | `greedy()` | projects, budget, ranking key | portfolio funded down the list |
| `carbon_iq/optimize.py` | `baselines()` | projects, budget, target | the three ranking baselines |

**7 · How should I explain it to judges?**

> We compare Mezan with the way companies usually decide: sort projects by one number and fund from the top. Sorting by cheapest tonne would pick a plan that loses money here. Sorting by NPV happens to match our answer - our added value is the confidence behind it.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/optimize.py :: greedy()
def greedy(prj, inter, budget, key, label, require_positive_npv=True):
    """Rank projects by `key` and fund down the list while budget allows (the usual one-by-one ranking)."""
    order = sorted(ALL, key=key)
    pick, spent = [], 0.0
    for i in order:
        if require_positive_npv and float(prj[i]["npv"]) <= 0:
            continue
        if spent + float(prj[i]["capex"]) <= budget + 1e-6:
            pick.append(i); spent += float(prj[i]["capex"])
    t = portfolio(pick, prj, inter)
    return {"method": label, "ids": tuple(sorted(pick)), "portfolio": "+".join(sorted(pick)) or "(none)",
            **{k: float(v) for k, v in t.items()}, "order": "".join(order)}
```

*Advanced:* Rankings ignore the target and combinations; they are shown for comparison only.

## 16. Multi-criteria decision analysis (MCDA, weighted scoring)

**Status: Not implemented.**

**1 · What is it?** MCDA scores each option on several criteria (value, carbon, risk, ease), weights the criteria, and ranks options by the weighted total.

**2 · Where did it come from?** Multi-attribute decision analysis: Keeney & Raiffa (1976).
- Keeney, R. L. & Raiffa, H. (1976). Decisions with Multiple Objectives: Preferences and Value Tradeoffs. Wiley (Cambridge University Press edition 1993). [https://doi.org/10.1017/CBO9781139174084](https://doi.org/10.1017/CBO9781139174084)

**3 · Why does Mezan need it?** Not used, because weights are subjective and would need agreement with the company's decision-makers. Mezan instead turns carbon and risk into explicit limits (constraints).

**4 · How does it work?**
1. Not computed. A weighted method would: score every project on each criterion (0-1).
2. Multiply each score by an agreed weight and add them up.
3. Rank by the total - and test how the ranking changes with the weights.

**5 · Simple example** Illustration only (not computed): weights 50% value, 30% carbon, 20% risk; a project scoring 0.8, 0.4, 0.9 gets 0.5×0.8 + 0.3×0.4 + 0.2×0.9 = 0.70.

**6 · How did we implement it?** Not implemented. Mezan assigns no weights and computes no combined score. Its decision rules maximise expected NPV subject to carbon and budget confidence constraints - a constrained single-objective method, which is not MCDA. The single-criterion rankings above are not MCDA either.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/decisions.py` | `choose()` | portfolio probabilities, budget, required levels | related, not MCDA: max expected NPV subject to the carbon and budget constraints |

**7 · How should I explain it to judges?**

> Mezan does not use weighted scoring. Weights are a matter of opinion, so instead we set the carbon target and the budget confidence as hard limits and maximise value within them. Adding weighted MCDA would be a future step, agreed with the company.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/decisions.py :: choose()
def choose(pr, budget, alpha=None, beta=None):
    """Index of the max-E[NPV] portfolio with quoted capex <= budget and the given reliability levels (None = no
    requirement). Returns None when no portfolio qualifies (infeasible) - no recommendation is forced."""
    cand = [k for k in range(len(pr["quote"])) if pr["quote"][k] <= budget + 1e-6
            and (alpha is None or pr["p_target"][k] >= alpha - 1e-12)
            and (beta is None or pr["p_budget"][k] >= beta - 1e-12)]
    return max(cand, key=lambda k: pr["e_npv"][k]) if cand else None
```

*Advanced:* An epsilon-constraint view: one objective (expected NPV) is optimised while the others (carbon, budget risk) are constraints; the efficient frontier shows the trade-off.

## 17. Portfolio optimisation under a budget

**Status: Fully implemented.**

**1 · What is it?** Finds the combination of projects with the highest value that fits the budget and meets the carbon target.

**2 · Where did it come from?** Capital rationing (Lorie & Savage, 1955); integer programming solved by branch-and-bound (Land & Doig, 1960).
- Lorie, J. H. & Savage, L. J. (1955). Three problems in rationing capital. Journal of Business 28(4), 229-239. [https://ideas.repec.org/r/ucp/jnlbus/v28y1955p229.html](https://ideas.repec.org/r/ucp/jnlbus/v28y1955p229.html)
- Land, A. H. & Doig, A. G. (1960). An automatic method of solving discrete programming problems. Econometrica 28(3), 497-520. [https://doi.org/10.2307/1910129](https://doi.org/10.2307/1910129)

**3 · Why does Mezan need it?** Six projects give 64 plans. The best plan is rarely 'the top projects until the money runs out'.

**4 · How does it work?**
1. Give each project a yes/no switch.
2. Rules: total cost ≤ budget; total cut ≥ target; shared savings counted once.
3. Let the solver find the highest-NPV combination; check by trying every combination.

**5 · Simple example** Synthetic: A+B+C, SAR 4.05M, 1,755 t/yr, NPV SAR 1.56M - best of all plans within SAR 5M meeting 1,358 t.

**6 · How did we implement it?** Binary integer program (HiGHS) cross-checked by enumerating all 64 portfolios; MRC uses the same functions on 16.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/optimize.py` | `solve_milp()` | projects, overlap, budget, target | optimal portfolio (HiGHS) |
| `carbon_iq/optimize.py` | `enumerate_best()` | projects, overlap, budget, target | best of all 64 portfolios + every row |
| `carbon_iq/engine.py` | `portfolio()` | selected ids | capex, NPV, tonnes with the B-C overlap removed |
| `carbon_iq/mrc.py` | `portfolios()` | MRC parameter set | best of the 16 MRC portfolios |

**7 · How should I explain it to judges?**

> With six projects there are 64 possible plans. Instead of guessing, Mezan checks every one: it keeps the plans that fit the five-million budget and hit the carbon target, then picks the most valuable - solar, efficient motors and compressed-air repair, for 4.05 million riyals and about 1,755 tonnes a year.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/optimize.py :: solve_milp()
def solve_milp(prj, inter, budget, target, exclusive=()):
    _check_finite(prj, inter)
    ids = list(ALL)
    n = len(ids)
    npv = np.array([float(prj[i]["npv"]) for i in ids] + [-float(inter["BC"]["npv"])])
    cap = np.array([float(prj[i]["capex"]) for i in ids] + [0.0])
    t12 = np.array([float(prj[i]["scope12_t"]) for i in ids] + [-float(inter["BC"]["scope12_t"])])
    iB, iC, iy = ids.index("B"), ids.index("C"), n
    A, lo, hi = [cap, t12], [-np.inf, target], [budget, np.inf]
    def row(d):
        r = np.zeros(n + 1)
        for k, val in d.items():
            r[k] = val
        return r
    A += [row({iy: 1, iB: -1, iC: -1}), row({iy: 1, iB: -1}), row({iy: 1, iC: -1})]
    lo += [-1, -np.inf, -np.inf]; hi += [np.inf, 0, 0]
    for a, b in exclusive:
        A.append(row({ids.index(a): 1, ids.index(b): 1})); lo.append(-np.inf); hi.append(1)
    res = milp(c=-npv, constraints=LinearConstraint(np.array(A), lo, hi), integrality=np.ones(n + 1),
               bounds=Bounds(0, 1))
    if not res.success:
        return None
    x = np.round(res.x).astype(int)
    sel = tuple(i for i, xi in zip(ids, x[:n]) if xi)
    return {"ids": sel, "portfolio": "+".join(sel) or "(none)", "npv": -res.fun, "status": res.message}
```

*Advanced:* The optimiser agreed with exhaustive search in all 3,267 budget/target cases tested in A6.

## 18. Sensitivity analysis

**Status: Fully implemented.**

**1 · What is it?** Finds which assumptions move the result most and at what value the recommended plan would change.

**2 · Where did it come from?** Tornado charts from decision analysis; variance-based indices by Sobol and Saltelli et al. (2008).
- Saltelli, A. et al. (2008). Global Sensitivity Analysis: The Primer. Wiley. [https://doi.org/10.1002/9780470725184](https://doi.org/10.1002/9780470725184)
- Sobol, I. M. (2001). Global sensitivity indices for nonlinear mathematical models and their Monte Carlo estimates. Mathematics and Computers in Simulation 55, 271-280. [https://doi.org/10.1016/S0378-4754(00)00270-6](https://doi.org/10.1016/S0378-4754(00)00270-6)

**3 · Why does Mezan need it?** Shows judges and managers which assumptions really matter, and where the answer could flip.

**4 · How does it work?**
1. Move one input from its 5th to its 95th percentile and record the NPV change (tornado).
2. Measure each input's share of the total variation from the Monte Carlo runs.
3. Sweep key inputs to find the switch point where the best plan changes.

**5 · Simple example** Tariff moves A+B+C's NPV by SAR 2.0M but never changes the plan; compressed-air savings below 20% switch it to A+B.

**6 · How did we implement it?** Tornado, first-order variance indices, switch points, discount-rate robustness, price scenarios; Sobol indices in the A6 validation script.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/sensitivity.py` | `tornado()` | portfolio ids | NPV at each input's 5th and 95th percentile |
| `carbon_iq/sensitivity.py` | `first_order()` | scenarios, output | first-order variance shares |
| `carbon_iq/sensitivity.py` | `switch_points()` | budget, inputs | values where the best plan changes |
| `tools/run_a6.py` | `gsa()` | sample size | Sobol first and total indices (validation) |
| `carbon_iq/mrc.py` | `tornado()` | MRC ids and parameters | one-way NPV sensitivity for MRC |

**7 · How should I explain it to judges?**

> We ask which assumptions really matter. The electricity tariff changes the plan's value the most - by about two million riyals - but never changes the recommendation. The real knife-edge is compressed-air savings: below 20%, the best plan changes. That is the number we would verify first, before committing the money.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/sensitivity.py :: tornado()
def tornado(ids, keys=None):
    base = base_values()
    b_npv, b_t = portfolio_npv(ids, base)
    rows = []
    for k in (keys or [k for k in P if P[k].dist is not None]):
        lv = pct_values(k)
        if lv is None:
            continue
        res = []
        for val in lv:
            q = dict(base); q[k] = val
            res.append(portfolio_npv(ids, q))
        rows.append({"parameter": k, "low": lv[0], "high": lv[1], "npv_low": res[0][0], "npv_high": res[1][0],
                     "t12_low": res[0][1], "t12_high": res[1][1], "swing": abs(res[1][0] - res[0][0]),
                     "base_npv": b_npv, "base_t12": b_t})
    rows.sort(key=lambda r: -r["swing"])
    return rows
```

*Advanced:* One-at-a-time tests miss interactions; the Sobol indices in A6 cover them for the key decision.

## 19. Investment timing and flexibility (real options)

**Status: Partially implemented.**

**1 · What is it?** Values the option to wait: should a project start now, or later when an uncertain price becomes clearer?

**2 · Where did it come from?** 'Real options' coined by Myers (1977); Dixit & Pindyck (1994); simulation method by Longstaff & Schwartz (2001).
- Myers, S. C. (1977). Determinants of corporate borrowing. Journal of Financial Economics 5(2), 147-175. [https://doi.org/10.1016/0304-405X(77)90015-0](https://doi.org/10.1016/0304-405X(77)90015-0)
- Dixit, A. K. & Pindyck, R. S. (1994). Investment under Uncertainty. Princeton University Press. [https://ideas.repec.org/b/pup/pbooks/5474.html](https://ideas.repec.org/b/pup/pbooks/5474.html)
- Longstaff, F. A. & Schwartz, E. S. (2001). Valuing American options by simulation: a simple least-squares approach. Review of Financial Studies 14(1), 113-147. [https://doi.org/10.1093/rfs/14.1.113](https://doi.org/10.1093/rfs/14.1.113)

**3 · Why does Mezan need it?** Ordinary NPV assumes 'now or never'. Waiting for a gas-price reform can avoid a loss.

**4 · How does it work?**
1. Describe how the price may move (a 50% chance of reform within a year).
2. Compare 'invest now' with 'wait, then invest only if worthwhile'.
3. Compute a trigger price above which investing pays.

**5 · Simple example** Heat recovery at USD 2.15/MMBtu: NPV −SAR 0.31M; waiting avoids an expected SAR 0.22M loss; break-even ≈ USD 3.85.

**6 · How did we implement it?** Implemented for one project (D, heat recovery) and one uncertain price (gas): decision tree, GBM trigger, least-squares Monte Carlo. Not applied to MRC.

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/timing.py` | `decision_tree()` | reform probability, prices | invest-now vs wait values |
| `carbon_iq/timing.py` | `gbm_trigger()` | drift, volatility, rate | price trigger for investing |
| `carbon_iq/timing.py` | `lsmc()` | price model, paths | option value by least-squares Monte Carlo |

**7 · How should I explain it to judges?**

> Some projects depend on prices that may soon change. Furnace heat recovery saves gas, and Saudi gas prices may be reformed. At today's price it loses money, so instead of saying 'no forever', Mezan says 'wait and watch': invest when the gas price passes a trigger. That flexibility has real value.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/timing.py :: decision_tree()
def decision_tree(p_reform=None, g_reform=None, g_now=None, d=None, r=None):
    """Prototype timing method for an ADMINISTERED price: a one-period reform tree.
    Invest now: year-1 savings at today's price, years 2..L at the expected post-decision price.
    Wait one year: invest only in the states where the full-life NPV is positive."""
    p_reform = v("tree_p_reform") if p_reform is None else p_reform
    g_reform = v("tree_g_reform") if g_reform is None else g_reform
    g_now = v("gas_price_usd") if g_now is None else g_now
    d = d or project_d()
    r = v("discount_rate") if r is None else r
    unit = d["q_gj"] * USD_MMBTU_TO_SAR_GJ
    L = d["life"]
    eg = p_reform * g_reform + (1 - p_reform) * g_now
    now = -d["capex"] + (unit * g_now - d["om"]) / (1 + r) + sum((unit * eg - d["om"]) / (1 + r) ** k for k in range(2, L + 1))
    npv_hi, npv_lo = static_npv(g_reform, d, r), static_npv(g_now, d, r)
    wait = (p_reform * max(npv_hi, 0.0) + (1 - p_reform) * max(npv_lo, 0.0)) / (1 + r)
    return {"p_reform": p_reform, "g_reform_usd": g_reform, "g_now_usd": g_now, "npv_invest_now": now,
            "npv_if_reform_at_t1": npv_hi, "npv_if_no_reform_at_t1": npv_lo, "value_wait_one_year": wait,
            "option_premium": max(now, wait) - now, "decision": "invest now" if now >= wait else "wait for the price decision",
            "static_breakeven_usd": static_breakeven_usd(d, r), "deferred_t_year1": d["q_gj"] * v("ef_gas")}
```

*Advanced:* The GBM trigger (about USD 17) reflects a high assumed volatility, not a forecast.

## 20. Decision-stability checks

**Status: Fully implemented.**

**1 · What is it?** Asks whether the recommendation would survive small changes in the data, the assumptions or the random sample.

**2 · Where did it come from?** Sampling error of scenario-based probabilities (Pagnoncelli, Ahmed & Shapiro, 2009); robustness testing in sensitivity analysis (Saltelli et al., 2008).
- Pagnoncelli, B. K., Ahmed, S. & Shapiro, A. (2009). Sample average approximation method for chance constrained programming. J. Optimization Theory and Applications 142, 399-416. [https://doi.org/10.1007/s10957-009-9523-6](https://doi.org/10.1007/s10957-009-9523-6)
- Saltelli, A. et al. (2008). Global Sensitivity Analysis: The Primer. Wiley. [https://doi.org/10.1002/9780470725184](https://doi.org/10.1002/9780470725184)

**3 · Why does Mezan need it?** A recommendation that flips with a 1% data change, or with a different random sample, should not be presented as settled.

**4 · How does it work?**
1. Measure how far each probability sits from its 90% threshold, in Monte Carlo standard errors.
2. Re-run the decision with estimated data at the edges of their intervals and at switch points.
3. Flag ⚠ any choice that is closer than 2 standard errors or that changes.

**5 · Simple example** MRC scenario: A+B+C keeps the budget in 90.66% of 20,000 futures vs the 90.35% required - only 1.4 standard errors; flagged as a knife-edge.

**6 · How did we implement it?** Monte Carlo margins in standard errors, perturbation of estimated data, switch points, knife-edge seeds, capital-cost risk and regret (synthetic plant); budget-margin check for MRC (v2.1).

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/dataquality/stability.py` | `margins()` | activity with uncertainty | distance from each threshold |
| `carbon_iq/dataquality/stability.py` | `assess()` | activity | STABLE / not stable per rule, switch points |
| `carbon_iq/decisions.py` | `knife_edge()` | scenarios, portfolio | probability across random seeds |
| `carbon_iq/decisions.py` | `capex_risk()` | scenarios, budget | cost-overrun probabilities |
| `carbon_iq/uncertainty.py` | `Scenarios.regret()` | budget, target | average regret per portfolio |
| `carbon_iq/mrc.py` | `monte_carlo()` | MRC parameters | budget margin in standard errors per plan |

**7 · How should I explain it to judges?**

> We check whether our answer is stable. If a small change in data or in the random sample could flip it, Mezan shows a warning instead of a confident recommendation - as it does for the MRC scenario, where the best plan passes the budget rule by a hair.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/dataquality/stability.py :: margins()
def margins(activity, n=20000, seed=20261024, budget=None, alpha=None, beta=None, ctx=None, res=None):
    if ctx is None:
        res, ctx = I.run_decisions(activity, n, seed, budget, alpha, beta)
    sc, pr, ch = ctx["sc"], ctx["pr"], ctx["choices"]
    budget, a_eff, b_eff, n = ctx["budget"], ctx["a_eff"], ctx["b_eff"], sc.n
    afford = [k for k in range(len(sc.ports)) if pr["quote"][k] <= budget + 1e-6]
    se = lambda p: float(np.sqrt(max(p * (1 - p), 1e-12) / n))  # noqa: E731
    rows = []
    # D1 deterministic
    best = ctx["best"]
    if best:
        _, allrows = I.O.enumerate_best(ctx["prj"], ctx["inter"], budget, ctx["T"])
        others = sorted([r for r in allrows if r["feasible"] and r["portfolio"] != best["portfolio"]], key=lambda r: -r["npv"])
        red = float(best["scope12_t"])
        rows.append(dict(rule="D1", choice=best["portfolio"], threshold="Scope 1+2 reduction >= target (deterministic)",
                         value=red, limit=ctx["T"], margin=red - ctx["T"], margin_rel=(red - ctx["T"]) / ctx["T"],
                         margin_se=np.nan, runner_up=others[0]["portfolio"] if others else "",
                         runner_up_gap=float(best["npv"] - others[0]["npv"]) if others else np.nan,
                         sampling_unstable=False))
    # D2 expected NPV
    k2 = ch["D2"]
    alt = sorted([k for k in afford if k != k2], key=lambda k: -pr["e_npv"][k])[0]
    diff = sc.PNPV[k2] - sc.PNPV[alt]
    se2 = float(diff.std(ddof=1) / np.sqrt(n))
    rows.append(dict(rule="D2", choice=sc.name(k2), threshold="highest E[NPV] among affordable portfolios",
                     value=float(pr["e_npv"][k2]), limit=float(pr["e_npv"][alt]), margin=float(diff.mean()),
                     margin_rel=float(diff.mean() / abs(pr["e_npv"][k2])), margin_se=float(diff.mean() / se2) if se2 > 0 else np.inf,
                     runner_up=sc.name(alt), runner_up_gap=float(diff.mean()), sampling_unstable=bool(diff.mean() < SE_LIMIT * se2)))
    # ... 42 more lines in carbon_iq/dataquality/stability.py
```

*Advanced:* Two standard errors is the flag threshold; it is a convention, not a guarantee.

## 21. Risk register

**Status: Not implemented.**

**1 · What is it?** A table of what could go wrong, how likely and how severe it is, who owns it and what is done about it.

**2 · Where did it come from?** ISO 31000:2018 risk-management guidelines.
- ISO 31000:2018. Risk management - Guidelines. International Organization for Standardization. [https://www.iso.org/standard/65694.html](https://www.iso.org/standard/65694.html)

**3 · Why does Mezan need it?** Management needs one place to track risks such as an unverified emission factor or a missing supplier quotation.

**4 · How does it work?**
1. Not computed. A register would list each risk with likelihood and impact (e.g. 1-5).
2. Multiply likelihood by impact to rank the risks.
3. Assign an owner and an action, and review regularly.

**5 · Simple example** Illustration only: 'MRC Scope 2 factor unverified' - likelihood 4, impact 4 → score 16 → owner: sustainability team; action: request the factor from Ma'aden.

**6 · How did we implement it?** Not implemented as a feature. Open risks are tracked in ISSUE_LOG.md (a document) and listed under each recommendation's limitations; no likelihood, impact or owner is calculated or stored by the app. The only quantified risk is the capital-cost overrun probability (decisions.capex_risk).

| File | Function | What goes in | What comes out |
|---|---|---|---|
| `carbon_iq/decisions.py` | `capex_risk()` | scenarios, budget | related: probability of exceeding the budget |

**7 · How should I explain it to judges?**

> Mezan quantifies decision risks - the chance of missing the target or exceeding the budget - but it does not yet keep a formal risk register with likelihoods, impacts and owners. Open risks, like the unverified Scope 2 factor, are listed in our issue log and under every recommendation.

**The actual Python code** (main function; read from the source):

```python
# carbon_iq/decisions.py :: capex_risk()
def capex_risk(sc, budget, target, alpha, levels=(0.8, 0.9, 0.95)):
    """Capital-cost risk table on the primary sample; `alpha` should already be the tightened level."""
    rows = []
    for st in sorted(sc.table(budget, target), key=lambda r: -r["e_npv"]):
        rows.append({k: (float(v) if isinstance(v, (float, np.floating)) else v) for k, v in st.items()
                     if k in ("portfolio", "capex", "e_capex", "p90_capex", "p95_capex", "p_over_budget",
                              "p_target", "p_target_and_budget", "e_npv", "contingency_p90")})
    variants = []
    for b in levels:
        k, e, pt, ok = sc.decide(budget, target, alpha, budget_reliability=b)
        variants.append({"budget_reliability": b, "portfolio": sc.name(k) if (k is not None and ok) else "none feasible",
                         "e_npv": _f(e) if ok else None, "p_target": _f(pt) if ok else None})
    # smallest budget at which the chance-constrained choice also stays within budget with 90% probability
    kc, *_ = sc.decide(budget, target, alpha)
    return {"table": rows, "with_budget_reliability": variants,
            "cc_portfolio": sc.name(kc), "cc_p90_capex": float(np.percentile(sc.PCAP[kc], 90)),
            "cc_contingency_p90": max(0.0, float(np.percentile(sc.PCAP[kc], 90)) - budget)}
```

*Advanced:* ISSUE_LOG.md is the closest artefact; turning it into a scored register is a documented next step.

## Examples: synthetic plant and MRC

| Method | Synthetic plant | MRC (2025 reported data) |
|---|---|---|
| Scope 1+2 accounting | 9,054 t (synthetic) | 160,632 t (reported, PDF p. 5) |
| Emission factors & units | 12,000 MWh × 0.573 = 6,876 t | 1,040,392 GJ ÷ 3.6 = 288,998 MWh; implied 0.335 t/MWh |
| Uncertainty propagation | ±7.7% on Scope 1+2 | ±4.0% on recalculated Scope 1 (assumed ±2% metering) |
| Data quality & missing data | 3 months of electricity unresolved; zero-filling hides 25% | Not applicable: annual totals only |
| Scope 1 cross-check | — | 64,105 t recalculated vs 63,961 t reported (+0.22%) |
| Scope 2 factor check | national 0.573 t/MWh (derived from national statistics) | implied 0.335 (derived, not verified) vs national 0.573 → 165,596 t |
| Budget feasibility | Solar at SAR 3,750/kWp: no plan passes within SAR 5M; minimum SAR 5.44M | Hypothetical: A+B+C needs SAR 69.9M of SAR 70M (knife-edge, flagged) |
| Single-criterion ranking | Cheapest tonne first: A+B+C+D+F, NPV −SAR 0.56M | not run |
| Multi-criteria analysis (weighted) | not implemented | not implemented |
| NPV / IRR / MAC | Solar: NPV SAR 1.25M, IRR 11.0%, MAC −97 SAR/t | Hypothetical 10 MWp solar valued with the same functions |
| Portfolio optimisation | A+B+C of 64 plans | Hypothetical scenario: best of 16 plans of A-D |
| Monte Carlo & probabilities | Target >99.99%, budget 98.8% (A+B+C) | Hypothetical scenario, register ranges |
| Value of information | EVPI SAR 55,670; only C sub-metering matters | Not run (no real cost or uncertainty data) |
| Real options | Wait on heat recovery; break-even gas USD 3.85 | Not run |

## Glossary

| Term | Meaning |
|---|---|
| tCO2e | Tonnes of carbon dioxide equivalent: all greenhouse gases converted to the CO2 amount with the same warming effect. |
| Scope 1 | Direct emissions from fuel burned on site (gas furnaces, diesel). |
| Scope 2 | Emissions from producing the electricity the site buys. |
| Scope 3 | Other value-chain emissions, e.g. making the steel the plant buys. |
| Emission factor | Tonnes of CO2e per unit of activity (per MWh, per GJ, per litre). |
| GJ / MWh | Energy units. 1 MWh = 3.6 GJ. |
| Activity data | The measured quantity: MWh bought, GJ of gas burned, litres of diesel. |
| Baseline | Emissions before any project, the reference for the target. |
| Uncertainty (± %, 95%) | Range that contains the true value 95 times out of 100. |
| Capex | Capital expenditure: the up-front investment cost. |
| Discount rate | How much less a future riyal is worth than today's (6% real per year here). |
| NPV | Net present value: discounted savings minus cost, in today's riyals. |
| IRR | Internal rate of return: the discount rate at which NPV = 0. |
| Payback | Years to recover the investment from yearly savings. |
| MAC | Marginal abatement cost: riyals per tonne of CO2e avoided (negative = saves money). |
| Portfolio | A combination of projects funded together. |
| Monte Carlo simulation | Testing a plan in thousands of randomly drawn futures. |
| Expected NPV, E[NPV] | Average NPV over all simulated futures. |
| Percentile (5th) | The value below which 5% of simulated outcomes fall - a 'bad case'. |
| Chance constraint | A rule such as 'meet the target in at least 90% of futures'. |
| EVPI | Expected value of perfect information: the most any information could be worth. |
| EVPPI | Value of perfect information about one input. |
| EVSI | Value of a real, imperfect measurement. |
| Sensitivity analysis | Testing which assumptions change the result most. |
| Switch point | The value of an input at which the recommended plan changes. |
| Real option | The value of being able to wait and decide later. |
| Synthetic data | Made-up data with realistic values, used to test methods. Not company data. |
| Reported data | Figures published by a company (here Ma'aden's 2025 data book). |
| Benchmark | A value from a published external source, used when company data are missing. |
| Hypothetical | An illustrative assumption made by Mezan; not a company value. |

## What the prototype proves

- The methods are correctly implemented: automated tests (127 before v2, more since), 28/28 injected errors caught, an independent re-implementation and spreadsheet agree (A6).
- On a synthetic plant, combining them changes the conversation: probabilities for target and budget, the value of extra data, and warnings when data are missing.
- The emissions arithmetic works on real reported data: MRC Scope 1 recalculated within 0.3% of Ma'aden's figure.

## What still needs real-world validation

- Accuracy on real monthly plant records (missing-data estimates were calibrated on synthetic data).
- Real project costs and savings: all MRC project inputs and five of six synthetic project costs are hypothetical.
- MRC's Scope 2 method: the implied factor (0.335 tCO2e/MWh) differs from the national average (0.573) and is not explained in the data book.
- Whether Saudi manufacturers face the decision gap Mezan targets (no interviews held yet).
- A real Google Colab run and an external review; Mezan is a research prototype, not production software.

## References

- WRI & WBCSD (2004). The Greenhouse Gas Protocol: A Corporate Accounting and Reporting Standard, revised edition. [https://ghgprotocol.org/corporate-standard](https://ghgprotocol.org/corporate-standard)
- IPCC (2006). 2006 IPCC Guidelines for National Greenhouse Gas Inventories, Vol. 2 Energy, Ch. 2 Stationary Combustion. [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf)
- IPCC (2006). 2006 Guidelines, Vol. 1, Ch. 3 Uncertainties (Approach 1: error propagation; Approach 2: Monte Carlo). [https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf](https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/1_Volume1/V1_3_Ch3_Uncertainties.pdf)
- JCGM 100:2008. Evaluation of measurement data - Guide to the Expression of Uncertainty in Measurement (GUM). BIPM. [https://www.bipm.org/en/doi/10.59161/JCGM100-2008E](https://www.bipm.org/en/doi/10.59161/JCGM100-2008E)
- Rubin, D. B. (1976). Inference and missing data. Biometrika 63(3), 581-592. [https://doi.org/10.1093/biomet/63.3.581](https://doi.org/10.1093/biomet/63.3.581)
- Little, R. J. A. & Rubin, D. B. (2019). Statistical Analysis with Missing Data, 3rd ed. Wiley. [https://doi.org/10.1002/9781119482260](https://doi.org/10.1002/9781119482260)
- Vovk, V., Gammerman, A. & Shafer, G. (2005). Algorithmic Learning in a Random World. Springer (conformal prediction). [https://doi.org/10.1007/b106715](https://doi.org/10.1007/b106715)
- Metropolis, N. & Ulam, S. (1949). The Monte Carlo method. Journal of the American Statistical Association 44(247), 335-341. [https://doi.org/10.1080/01621459.1949.10483310](https://doi.org/10.1080/01621459.1949.10483310)
- Charnes, A. & Cooper, W. W. (1959). Chance-constrained programming. Management Science 6(1), 73-79. [https://doi.org/10.1287/mnsc.6.1.73](https://doi.org/10.1287/mnsc.6.1.73)
- Pagnoncelli, B. K., Ahmed, S. & Shapiro, A. (2009). Sample average approximation method for chance constrained programming. J. Optimization Theory and Applications 142, 399-416. [https://doi.org/10.1007/s10957-009-9523-6](https://doi.org/10.1007/s10957-009-9523-6)
- Howard, R. A. (1966). Information value theory. IEEE Transactions on Systems Science and Cybernetics 2(1), 22-26. [https://doi.org/10.1109/TSSC.1966.300074](https://doi.org/10.1109/TSSC.1966.300074)
- Raiffa, H. & Schlaifer, R. (1961). Applied Statistical Decision Theory. Harvard Business School (book; no free link).
- HM Treasury (2022). The Green Book: appraisal and evaluation in central government. [https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government](https://www.gov.uk/government/publications/the-green-book-appraisal-and-evaluation-in-central-government)
- Kesicki, F. & Ekins, P. (2012). Marginal abatement cost curves: a call for caution. Climate Policy 12(2), 219-236. [https://ideas.repec.org/a/taf/tcpoxx/v12y2012i2p219-236.html](https://ideas.repec.org/a/taf/tcpoxx/v12y2012i2p219-236.html)
- Land, A. H. & Doig, A. G. (1960). An automatic method of solving discrete programming problems. Econometrica 28(3), 497-520. [https://doi.org/10.2307/1910129](https://doi.org/10.2307/1910129)
- Lorie, J. H. & Savage, L. J. (1955). Three problems in rationing capital. Journal of Business 28(4), 229-239. [https://ideas.repec.org/r/ucp/jnlbus/v28y1955p229.html](https://ideas.repec.org/r/ucp/jnlbus/v28y1955p229.html)
- Keeney, R. L. & Raiffa, H. (1976). Decisions with Multiple Objectives: Preferences and Value Tradeoffs. Wiley (Cambridge University Press edition 1993). [https://doi.org/10.1017/CBO9781139174084](https://doi.org/10.1017/CBO9781139174084)
- Saltelli, A. et al. (2008). Global Sensitivity Analysis: The Primer. Wiley. [https://doi.org/10.1002/9780470725184](https://doi.org/10.1002/9780470725184)
- Sobol, I. M. (2001). Global sensitivity indices for nonlinear mathematical models and their Monte Carlo estimates. Mathematics and Computers in Simulation 55, 271-280. [https://doi.org/10.1016/S0378-4754(00)00270-6](https://doi.org/10.1016/S0378-4754(00)00270-6)
- Myers, S. C. (1977). Determinants of corporate borrowing. Journal of Financial Economics 5(2), 147-175. [https://doi.org/10.1016/0304-405X(77)90015-0](https://doi.org/10.1016/0304-405X(77)90015-0)
- Dixit, A. K. & Pindyck, R. S. (1994). Investment under Uncertainty. Princeton University Press. [https://ideas.repec.org/b/pup/pbooks/5474.html](https://ideas.repec.org/b/pup/pbooks/5474.html)
- Longstaff, F. A. & Schwartz, E. S. (2001). Valuing American options by simulation: a simple least-squares approach. Review of Financial Studies 14(1), 113-147. [https://doi.org/10.1093/rfs/14.1.113](https://doi.org/10.1093/rfs/14.1.113)
- ISO 31000:2018. Risk management - Guidelines. International Organization for Standardization. [https://www.iso.org/standard/65694.html](https://www.iso.org/standard/65694.html)
- Ma'aden (2026). Sustainability Data Book 2025 (file supplied by the user; MRC figures on PDF page 5).
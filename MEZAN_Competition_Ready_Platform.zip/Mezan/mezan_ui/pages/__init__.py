"""One module per workspace."""
